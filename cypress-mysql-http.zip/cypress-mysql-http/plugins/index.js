const mysql = require("mysql");
const axios = require('axios');
function queryTestDb(query, config) {
  // creates a new mysql connection using credentials from cypress.json env's
  const connection = mysql.createConnection(config.env.db);
  // start connection to db
  connection.connect();
  // exec query + disconnect to db as a Promise
  return new Promise((resolve, reject) => {
    connection.query(query, (error, results) => {
      if (error) reject(error);
      else {
        connection.end();
        // console.log(results)
        return resolve(results);
      }
    });
  });
}

module.exports = (on, config) => {
  // Usage: cy.task('queryDb', query)
  on("task", {
    queryDb: query => {
      return queryTestDb(query, config);
    },

    async queryDatabase() {
      try {
        const response = await axios({
          url: 'http://127.0.0.1:5000/query',
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
          data: {
            mysqlQuery: "SELECT * FROM mysql.engine_cost",
          },
        });
        // Return the response data
        return response.data;

      } catch (error) {
        // Handle errors
        throw new Error(error.message);
      }
    },
  });
};