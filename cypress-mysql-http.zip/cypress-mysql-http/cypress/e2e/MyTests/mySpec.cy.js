describe('Database Query Test', () => {
  it('Should retrieve data from the database via API and log the result', () => {
    cy.task('queryDatabase').then((data) => {
      cy.log('Data retrieved from API:', data);
    });
  });
});
