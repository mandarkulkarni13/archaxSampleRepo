const { defineConfig } = require("cypress");
const axios = require('axios');

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      return require('./plugins/index.js')(on, config)
    },
    "projectId": "somId",
    "video": true,
    "env":{
      "db": {
        "host": "localhost",
        "port":"3306",
        "user": "root",
        "password": "DBPASSWORD",
        "database":"mysql"
      }
    }
  },
});


