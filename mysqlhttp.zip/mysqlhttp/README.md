## INSTRUCTIONS

- git clone https://github.com/tejozymandias/mysqlhttp.git
- cd mysqlhttp
- npm install

> In the database.js file, change the password and database name.
> Run Nodemon using the below command to start a HTTP Server on PORT 5000

- npm run dev
